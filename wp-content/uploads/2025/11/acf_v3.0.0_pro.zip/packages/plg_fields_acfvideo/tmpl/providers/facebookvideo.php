<?php

/**
 * @package         Advanced Custom Fields
 * @version         3.0.0 Pro
 * 
 * @author          Tassos Marinos <info@tassos.gr>
 * @link            http://www.tassos.gr
 * @copyright       Copyright © 2019 Tassos Marinos All Rights Reserved
 * @license         GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
*/

defined('_JEXEC') or die;

if (!$videoURL = $field->value)
{
	return;
}

$payload = [
	'value' => $videoURL,
	'width' => $fieldParams->get('width', '480px'),
	'height' => null,
	
	'fs' => $fieldParams->get('fs', '1') === '1',
	'autoplay' => $fieldParams->get('autoplay', '0') === '1',
	'autopause' => $fieldParams->get('autopause', '0') === '1',
	'show_text' => $fieldParams->get('show_text', '0') === '1',
	'show_captions' => $fieldParams->get('show_captions', '0') === '1',
	
];

// Set custom layout
if ($field->params->get('acf_layout_override'))
{
	$payload['layout'] = $field->params->get('acf_layout_override');
}

echo \NRFramework\Widgets\Helper::render('FacebookVideo', $payload);